package com.exemple;

import inteleonyx.myra.Config;
import inteleonyx.myra.RegisterCommands;
import inteleonyx.myra.commands.AvatarCommand;
import inteleonyx.myra.commands.MiscCommands;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.requests.GatewayIntent;

public class Client {
        public static void main(String[] args) {
            JDA jda = JDABuilder.createDefault(Config.TOKEN)
                    .disableIntents(GatewayIntent.GUILD_MEMBERS,
                            GatewayIntent.GUILD_PRESENCES,
                            GatewayIntent.GUILD_MESSAGES)
                    .setStatus(OnlineStatus.DO_NOT_DISTURB)
                    .setActivity(Activity.playing("sTATUS"))
                    .addEventListeners(//Listeners)
                    .build();
        }

    }
}