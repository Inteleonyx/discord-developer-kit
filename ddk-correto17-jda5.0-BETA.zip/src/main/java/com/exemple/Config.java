package inteleonyx.myra;

public class Config {

    public static final String TOKEN =
            "YOURTOKEN";


}
